# Hammerflow Grid Layout Modification Guide

This guide will walk you through modifying Hammerflow to display commands in a grid layout with columns sized by their widest entries, maximum 7 columns, and rows as needed.

## Prerequisites

- Hammerflow.spoon already installed and working
- Basic text editor (VS Code, nano, vim, etc.)
- Backup of your current setup (recommended)

## Step 1: Locate the Files

Navigate to your Hammerspoon directory:
```bash
cd ~/.hammerspoon/Spoons/Hammerflow.spoon
```

You'll be editing:
- `Spoons/RecursiveBinder.spoon/init.lua` (main modification)
- Optionally: `init.lua` (for configuration options - the file you provided)

## Step 2: Backup Current Files

```bash
# Create backup
cp Spoons/RecursiveBinder.spoon/init.lua Spoons/RecursiveBinder.spoon/init.lua.backup
```

## Step 3: Edit RecursiveBinder.spoon

Open the RecursiveBinder file:
```bash
code Spoons/RecursiveBinder.spoon/init.lua
# or
nano Spoons/RecursiveBinder.spoon/init.lua
```

### Find the Helper Display Function

Look for a function that handles displaying the helper popup. In RecursiveBinder, this is likely called:
- `recursiveBind` (the main function)
- A helper function within `recursiveBind` that shows the popup
- Look for code that calls `hs.alert.show()`

You'll find something similar to:
```lua
hs.alert.show(helpText, obj.helperFormat, hs.screen.mainScreen(), duration)
```

The existing code probably builds `helpText` by concatenating key-value pairs in a simple format.

### Add the Grid Formatting Function

**Add this new function** before the existing helper display function:

```lua
local function formatBindingsAsGrid(keymap)
    local MAX_COLS = 7
    local KEY_LABEL_SEP = " : "
    local COL_SPACING = "   "
    local items = {}
    
    -- Collect and sort items
    for key, binding in pairs(keymap) do
        -- Based on Hammerflow's singleKey structure: key = {mode, keyChar, label}
        local keyChar = key[2] or "?"
        local label = key[3] or keyChar
        table.insert(items, {key = keyChar, label = label})
    end
    
    -- Sort alphabetically by key
    table.sort(items, function(a, b) return a.key < b.key end)
    
    if #items == 0 then return "" end
    
    -- Calculate grid dimensions
    local numCols = math.min(#items, MAX_COLS)
    local numRows = math.ceil(#items / numCols)
    
    -- Create grid structure and calculate column widths
    local grid = {}
    local colWidths = {}
    
    -- Initialize column widths
    for col = 1, numCols do
        colWidths[col] = 0
    end
    
    -- Fill grid and find max width per column
    for row = 1, numRows do
        grid[row] = {}
        for col = 1, numCols do
            local itemIndex = (row - 1) * numCols + col
            if itemIndex <= #items then
                local item = items[itemIndex]
                local cellContent = item.key .. KEY_LABEL_SEP .. item.label
                grid[row][col] = cellContent
                
                -- Update column width if this entry is wider
                colWidths[col] = math.max(colWidths[col], string.len(cellContent))
            else
                grid[row][col] = nil -- Empty cell
            end
        end
    end
    
    -- Build final formatted rows
    local rows = {}
    for row = 1, numRows do
        local rowItems = {}
        for col = 1, numCols do
            if grid[row][col] then
                -- Left-align and pad to column width
                local padded = grid[row][col] .. string.rep(" ", colWidths[col] - string.len(grid[row][col]))
                table.insert(rowItems, padded)
            else
                -- Empty cell - maintain alignment
                table.insert(rowItems, string.rep(" ", colWidths[col]))
            end
        end
        table.insert(rows, table.concat(rowItems, COL_SPACING))
    end
    
    return table.concat(rows, "\n")
end
```

### Modify the Display Function

Find the existing helper display function. It's likely inside the `recursiveBind` function or a similar main function. Look for code that builds help text, something like:

```lua
-- OLD CODE (look for something similar to this):
local helpText = ""
for key, value in pairs(keymap) do
    helpText = helpText .. key[2] .. ": " .. key[3] .. "\n"
end
hs.alert.show(helpText, obj.helperFormat, hs.screen.mainScreen(), math.huge)
```

**Replace that section** with:

```lua
-- NEW CODE (replace the above with this):
local gridText = formatBindingsAsGrid(keymap)

if gridText ~= "" then
    hs.alert.show(gridText, obj.helperFormat, hs.screen.mainScreen(), math.huge)
end
```

**Note**: The exact variable names and structure may differ in your RecursiveBinder. The key is to find where the help text is built and displayed, then replace it with the grid formatting function.

## Step 4: Optional Configuration (Advanced)

If you want to make the grid customizable, edit the main `init.lua`:

```bash
code init.lua
```

### Add Configuration Options

Find the `loadFirstValidTomlFile` function (around line 283) and locate this section:
```lua
spoon.RecursiveBinder.helperFormat = hs.alert.defaultStyle

-- clear settings from table so we don't have to account
-- for them in the recursive processing function
configFile.leader_key = nil
configFile.leader_key_mods = nil
configFile.auto_reload = nil
configFile.toast_on_reload = nil
configFile.show_ui = nil
```

**Add these lines** just before the `configFile.leader_key = nil` section:

```lua
-- Grid layout configuration
local maxCols = configFile.max_grid_columns or 7
local gridSpacing = configFile.grid_spacing or "   "
local gridSeparator = configFile.grid_separator or " : "

-- Pass to RecursiveBinder
spoon.RecursiveBinder.maxColumns = maxCols
spoon.RecursiveBinder.gridSpacing = gridSpacing  
spoon.RecursiveBinder.gridSeparator = gridSeparator

-- Add to cleanup section
configFile.max_grid_columns = nil
configFile.grid_spacing = nil
configFile.grid_separator = nil
```

### Update Grid Function to Use Config

Then modify the grid function in RecursiveBinder to use these values:

```lua
local function formatBindingsAsGrid(keymap)
    local MAX_COLS = obj.maxColumns or 7
    local KEY_LABEL_SEP = obj.gridSeparator or " : "
    local COL_SPACING = obj.gridSpacing or "   "
    -- ... rest of the function remains the same
end
```

### Add to Your TOML Config

Add these optional settings to your configuration file (e.g., `home.toml`, `work.toml`, or `sample.toml`):

```toml
# Existing settings...
leader_key = "f18"
auto_reload = true
show_ui = true

# NEW: Grid layout options (optional - these are the defaults)
max_grid_columns = 7        # Maximum columns (1-10 recommended)
grid_spacing = "   "        # Spacing between columns (3 spaces)
grid_separator = " : "      # Separator between key and label

# Your existing key bindings...
t = "Terminal"
v = ["Visual Studio Code", "VS Code"]
# etc...
```

**Note**: These configuration options are optional. If you don't add them, the defaults (7 columns, 3-space separation, " : " separator) will be used.

## Step 5: Test Your Changes

1. **Reload Hammerspoon**:
   - Press `⌘ + ⌥ + ⌃ + R`
   - Or from menu: Hammerspoon → Reload Config

2. **Test the Grid**:
   - Press your leader key (default F18)
   - You should see commands arranged in a grid
   - Try different levels of nesting to see the grid adapt

## Step 6: Troubleshooting

### If Nothing Appears
Check Hammerspoon Console for errors:
- Menu: Hammerspoon → Console
- Look for any Lua errors

### If Layout Looks Wrong
1. Check that you modified the correct function
2. Verify the `formatBindingsAsGrid` function was added correctly
3. Make sure you didn't accidentally break existing code

### Common Issues

**Error: "attempt to index nil value"**
- The key structure might be different than expected
- Add debug logging: `print("Key structure:", hs.inspect(key))`

**Grid not showing**
- Verify `obj.showBindHelper` is true
- Check that the display function is being called

### Debug the Key Structure

If the grid isn't showing correctly, add this temporary debug code to understand your key structure:

```lua
local function formatBindingsAsGrid(keymap)
    -- DEBUG: Print key structure to Hammerspoon Console
    print("=== DEBUG: Key structure ===")
    local count = 0
    for key, binding in pairs(keymap) do
        print("Key " .. count .. ":", hs.inspect(key))
        count = count + 1
        if count >= 3 then break end -- Only print first 3
    end
    print("=== End DEBUG ===")
    
    -- ... rest of function
end
```

Check the Hammerspoon Console (Menu: Hammerspoon → Console) to see the actual key structure, then adjust the key parsing accordingly:

```lua
-- If keys look like {nil, "a", "Terminal"}:
local keyChar = key[2]
local label = key[3]

-- If keys look like {"a", "Terminal"}:
local keyChar = key[1]  
local label = key[2]

-- If keys are different, adjust accordingly
```

## Step 7: Customization Options

### Change Visual Style

Modify these variables in the grid function:

```lua
local KEY_LABEL_SEP = " → "     -- Try: " │ ", " ▸ ", " ◦ "
local COL_SPACING = "    "      -- More/less space between columns
```

### Different Column Limits

Change the maximum columns:

```lua
local MAX_COLS = 5  -- Or any number 1-10
```

## Step 8: Make It Permanent

Once everything works:

1. **Remove debug code** if you added any
2. **Test thoroughly** with different key combinations
3. **Document your changes** for future reference

## Rollback Instructions

If something goes wrong:

```bash
cd ~/.hammerspoon/Spoons/Hammerflow.spoon
cp Spoons/RecursiveBinder.spoon/init.lua.backup Spoons/RecursiveBinder.spoon/init.lua
```

Then reload Hammerspoon.

## Example Output

With these changes, your popup will look like:

```
a : Terminal       b : VS Code        c : Chrome
d : Calculator     e : Settings       f : Finder
g : Mail
```

Instead of the original vertical list:

```
a: Terminal
b: VS Code  
c: Chrome
d: Calculator
e: Settings
f: Finder
g: Mail
```

The grid automatically adjusts column widths and adds rows as needed while never exceeding 7 columns.