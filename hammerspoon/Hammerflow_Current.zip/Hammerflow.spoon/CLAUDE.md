# Hammerflow.spoon Development Guidelines

## Commands
- No formal build process (Lua-based Hammerspoon Spoon)
- No specific testing framework or commands
- Test changes by loading the Spoon in Hammerspoon
- Debug with `hs.console.clearConsole()` and `hs.alert()`

## Code Style Guidelines

### Formatting
- Two-space indentation
- Spaces around operators and after commas
- Keep line length under 100 characters
- Use blank lines to separate logical sections

### Naming Conventions
- Local variables: camelCase (e.g., `leaderKey`, `configFile`)
- Functions: camelCase (e.g., `loadFirstValidTomlFile`)
- Private properties: prefixed with underscore (e.g., `obj._userFunctions`)
- Constants: snake_case (e.g., `leader_key`, `auto_reload`)

### Structure
- Export a single `obj` table as the main interface
- Define helper functions locally within the module
- Group related functions together
- Split complex operations into smaller functions

### Error Handling
- Use Lua's `error()` function for critical errors
- Use `hs.alert` or `hs.notify` for user-facing errors
- Use `pcall` for error-prone operations (e.g., TOML parsing)

### Imports
- Load external dependencies at the top of files
- Use relative path imports for local modules
- Modify `package.path` for local Spoon inclusion